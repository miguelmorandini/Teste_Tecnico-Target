﻿namespace Teste_Tecnico_Target
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Teste Técnico para vaga de estágio - Target Ribeirão Preto*/
            //Miguel Miranda Morandini
        }
    }
}
